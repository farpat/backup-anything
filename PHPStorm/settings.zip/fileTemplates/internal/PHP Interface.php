<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end

interface ${NAME} {

}