<template>
#[[$END$]]#
</template>

<script>
export default {
}
</script>