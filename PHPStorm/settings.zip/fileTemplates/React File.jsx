import React from 'react';
import PropTypes from 'prop-types';

function ${NAME}(props) {
    return (
        <div>
            Here ${NAME} in ${FILE_NAME}
        </div>
    );
}

${NAME}.propTypes = {
    id:         PropTypes.number.isRequired,
};

export default ${NAME}
