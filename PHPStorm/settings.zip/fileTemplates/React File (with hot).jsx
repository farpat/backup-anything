import React from "react";
import {hot} from "react-hot-loader/root";
import PropTypes from 'prop-types';

class ${NAME} extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                Here ${NAME} in ${FILE_NAME}
            </div>
        );
    }
}

${NAME}.propTypes = {
    id:         PropTypes.number.isRequired,
};

export default hot(${NAME});
