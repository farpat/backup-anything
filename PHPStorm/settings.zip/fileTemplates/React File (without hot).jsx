import React from "react";
import PropTypes from 'prop-types';

class ${NAME} extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                Here ${NAME} in ${FILE_NAME}
            </div>
        );
    }
}

${NAME}.propTypes = {
    id:         PropTypes.number.isRequired,
};

export default ${NAME};
